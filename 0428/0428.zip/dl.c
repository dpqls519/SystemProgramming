#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<fcntl.h>
#include<dirent.h>
#include<sys/stat.h>
#include<unistd.h>
#include<time.h>
#include<grp.h>
#include<pwd.h>

//타입 확인
void dl_Type(mode_t mmode){
    if(S_ISREG(mmode))
        putchar('-');
    else if(S_ISREG(mmode))
        putchar('d');
    else if(S_ISREG(mmode))
        putchar('c');
    else if(S_ISREG(mmode))
        putchar('b');
    else if(S_ISREG(mmode))
        putchar('p');
    else if(S_ISREG(mmode))
        putchar('l');
    else if(S_ISREG(mmode))
        putchar('s');
}

//permission확인
void dl_per(mode_t pmode)
{
    //User//
    if(pmode&S_IRUSR)
        putchar('r');
    else
        putchar('-');
    if(pmode&S_IWUSR)
        putchar('w');
    else
        putchar('-');
    if(pmode&S_IXUSR)
        putchar('x');
    else
        putchar('-');

    //Group//
    if(pmode&S_IRGRP)
        putchar('r');
    else
        putchar('-');
    if(pmode&S_IWGRP)
        putchar('w');
    else
        putchar('-');
    if(pmode&S_IXGRP)
        putchar('x');
    else
        putchar('-');

    //Other//
    if(pmode&S_IROTH)
        putchar('r');
    else
        putchar('-');
    if(pmode&S_IWOTH)
        putchar('w');
    else
        putchar('-');
    if(pmode&S_IXOTH)
        putchar('x');
    else
        putchar('-');
}

//user id 확인
void dl_uid(uid_t uid)
{
    struct passwd *uuid=(struct passwd*)malloc(sizeof(struct passwd));
    uuid=getpwuid(uid);
    printf("  %s",uuid->pw_name);
}

//link 수 확인
void dl_linkcnt(nlink_t lcnt)
{
    printf("  %ld",lcnt);
}

//group id 확인
void dl_gid(gid_t gid)
{
    struct group* grp=(struct group*)malloc(sizeof(struct group));
    grp=getgrgid(gid);
    printf("  %s",grp->gr_name);
}

//inode 확인
void dl_inode(ino_t inonum)
{
    printf("%-10ld",inonum);
}

//file 크기
void dl_filesize(off_t sz)
{
    printf("%10ld",sz);
}

//file 수정시간
void dl_filetime(time_t ttime)
{
    struct tm *tm_ptr;
    tm_ptr=localtime(&ttime);
    printf("  ");
    printf("%d월 %2d일 %2d:%2d",tm_ptr->tm_mon+1,tm_ptr->tm_mday,tm_ptr->tm_hour,tm_ptr->tm_min);
}

//파일 이름
void dl_filename(char *s)
{

    printf("\t%s",s);
}

//option
void dl_option(struct stat buf, char * option){
    if(strcmp(option, "-l")==0){
        dl_Type(buf.st_mode);
        dl_per(buf.st_mode);
        dl_linkcnt(buf.st_nlink);
        dl_uid(buf.st_uid);
        dl_gid(buf.st_gid);
        dl_filesize(buf.st_size);
        dl_filetime(buf.st_mtime);
    }
    else if(strcmp(option, "-i")==0){
        dl_inode(buf.st_ino);
    }
}

//출처 : https://blog.naver.com/corona78/30010050492

int main(int argc, char* argv[]) 
{
    char *cwd = (char*)malloc(sizeof(char)*1024);
    memset(cwd,0,1024);

    DIR* dir = NULL;
    struct dirent* entry;
    struct stat buf;

    getcwd(cwd,1024);

    if((dir = opendir(cwd)) ==NULL)
    {
        printf("opendir() error\n");
        exit(1);
    }
    while ((entry = readdir(dir)) != NULL){
        lstat(entry->d_name,&buf);
        if(argc>1)
            dl_option(buf,argv[1]);
        printf("%s  \n",entry->d_name);
    }
    
    free(cwd);
    closedir(dir);

    return 0;
}
