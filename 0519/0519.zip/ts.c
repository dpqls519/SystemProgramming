#include <stdio.h>

int main(void){
    char big;
    char small;

    printf("대문자 입력 : ");
    scanf(" %c", &big);
    printf("소문자 입력 : ");
    scanf(" %c", &small);

    printf("입력한 %c의 소문자는 %c입니다.\n", big, big+32);

    printf("입력한 %c의 대문자는 %c입니다.\n", small, small-32);
}


