<?
echo "Hello PHP world!!":
?>
